import React from 'react'

export default function Medicine() {
  return (
    <div>Medicine</div>
  )
}
