import { useEffect, useState } from "react";
import { collection, query, orderBy, onSnapshot, where } from "firebase/firestore"
import { db } from "../assets/js/firebase";
import { TbCirclePlus, TbDogBowl, TbSortAscendingLetters, TbSortDescendingLetters, TbSearch } from "react-icons/tb";

function Home() {}



export default Home;